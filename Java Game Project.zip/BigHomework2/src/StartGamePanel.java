import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class StartGamePanel extends JPanel {
    public StartGamePanel(Values values) {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        JLabel chooseDificulty=new JLabel("Choose dificulty");
        chooseDificulty.setAlignmentX(Component.CENTER_ALIGNMENT);

        JRadioButton choosedificulty=new JRadioButton("Easy");
        choosedificulty.setAlignmentX(Component.CENTER_ALIGNMENT);

        JRadioButton choosedificulty2=new JRadioButton("Medium");
        choosedificulty2.setAlignmentX(Component.CENTER_ALIGNMENT);

        JRadioButton choosedificulty3=new JRadioButton("Hard");
        choosedificulty3.setAlignmentX(Component.CENTER_ALIGNMENT);

        JRadioButton impossible = new JRadioButton("Impossible(1%)");
        impossible.setAlignmentX(Component.CENTER_ALIGNMENT);

        choosedificulty.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                values.choosesize=10;
                values.buttons = new JButton[values.choosesize][values.choosesize];
                Random random = new Random();
                values.numberofmoves=random.nextInt(50-20+1)+20;
                values.randomnumber=random.nextInt(150-50+1)+50;
                values.gamemode="Easy";
                values.movesleft.setText("Number of Moves "+values.numberofmoves);
                values.defaultMoves = values.numberofmoves;
                values.label.setText(values.gamemode);
                values.target.setText("Target Value"+ values.randomnumber);

                Container startGamePanel = choosedificulty.getParent();
                Container frame = startGamePanel.getParent();

                frame.remove(startGamePanel);

                GamePanel gamePanel = new GamePanel(values);
                frame.add(gamePanel);

                frame.repaint();
                frame.revalidate();
            }
        });

        choosedificulty2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                values.choosesize=15;
                values.buttons = new JButton[values.choosesize][values.choosesize];
                Random random = new Random();
                values.numberofmoves=random.nextInt(100-40+1)+40;
                values.randomnumber=random.nextInt(300-150+1)+150;
                values.gamemode="Medium";
                values.label.setText(values.gamemode);
                values.movesleft.setText("Number of Moves "+values.numberofmoves);
                values.defaultMoves = values.numberofmoves;
                values.label.setText(values.gamemode);
                values.target.setText("Target Value"+ values.randomnumber);

                Container startGamePanel = choosedificulty2.getParent();
                Container frame = startGamePanel.getParent();

                frame.remove(startGamePanel);

                GamePanel gamePanel = new GamePanel(values);
                frame.add(gamePanel);

                frame.repaint();
                frame.revalidate();

            }
        });

        choosedificulty3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                values.choosesize=20;
                values.buttons = new JButton[values.choosesize][values.choosesize];
                Random random = new Random();
                values.numberofmoves=random.nextInt(400-300+1)+300;
                values.randomnumber=random.nextInt(1000-500+1)+500;
                values.gamemode="Hard";
                values.label.setText(values.gamemode);
                values.movesleft.setText("Number of Moves "+values.numberofmoves);
                values.defaultMoves = values.numberofmoves;
                values.label.setText(values.gamemode);
                values.target.setText("Target Value"+ values.randomnumber);

                Container startGamePanel = choosedificulty3.getParent();
                Container frame = startGamePanel.getParent();

                frame.remove(startGamePanel);

                GamePanel gamePanel = new GamePanel(values);
                frame.add(gamePanel);

                frame.repaint();
                frame.revalidate();
            }
        });

        impossible.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                values.choosesize=10;
                values.buttons = new JButton[values.choosesize][values.choosesize];
                values.numberofmoves=5;
                values.randomnumber=43;
                values.gamemode="Impossible";
                values.label.setText(values.gamemode);
                values.movesleft.setText("Number of Moves "+values.numberofmoves);
                values.defaultMoves = values.numberofmoves;
                values.label.setText(values.gamemode);
                values.target.setText("Target Value"+ values.randomnumber);

                Container startGamePanel = impossible.getParent();
                Container frame = startGamePanel.getParent();

                frame.remove(startGamePanel);

                GamePanel gamePanel = new GamePanel(values);
                frame.add(gamePanel);

                frame.repaint();
                frame.revalidate();
            }
        });

        ButtonGroup difficultyGroup = new ButtonGroup();
        difficultyGroup.add(choosedificulty);
        difficultyGroup.add(choosedificulty2);
        difficultyGroup.add(choosedificulty3);
        difficultyGroup.add(impossible);

        add(Box.createVerticalGlue());
        add(chooseDificulty);
        add(choosedificulty);
        add(choosedificulty2);
        add(choosedificulty3);
        add(impossible);
        add(Box.createVerticalGlue());
    }
}
