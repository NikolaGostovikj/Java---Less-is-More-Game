import javax.swing.*;
import java.awt.*;
import java.util.Random;

public class ButtonPanel extends JPanel{
    Values values;
    JButton buttons[][];
    boolean buttonTextsBool;
    public ButtonPanel(Values values){ //constructor ButtonPanel
        this.values = values;
        this.buttons=values.buttons;
        setLayout(new GridLayout(values.choosesize, values.choosesize, 5, 5));
        creatingButtons(); //calling the method in the constructor
    }
    public void creatingButtons() {
        if(values.buttonTexts[0] != null) {
            buttonTextsBool = true;   //
        }

        else {
            buttonTextsBool = false;
        } //checks if it has a value to load (restart, load)

        Random random = new Random();
        int index = 0;
        for (int i = 0; i < values.choosesize ; i++) {
            for (int j = 0; j < values.choosesize ; j++) {
                int randomint = random.nextInt(9)+1;
                String text = Integer.toString(randomint);
                if(buttonTextsBool == true) {
                    text = values.buttonTexts[index];
                    index++;  // if there is a value to be loaded it will placed on index and index will be incremented
                }
                //current position on the button in the game field
                //adding action listener to every button
                JButton button=new JButton(text);
                button.addActionListener(new Actions(buttons, values,new int []{i,j}));
                buttons[i][j]=button;
                add(buttons[i][j]);
            }
        }

        if(buttonTextsBool == true) {
            values.buttonTexts = new String[values.choosesize]; //if there was content that is written inside the buttons,
            //this variable will be reseted
        }
    }


}
