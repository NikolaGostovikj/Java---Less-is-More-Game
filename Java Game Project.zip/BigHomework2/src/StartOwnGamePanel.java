import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class StartOwnGamePanel extends JPanel {
    public StartOwnGamePanel(Values values) {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        JLabel label = new JLabel("Enter Dimension ( n x n, 10-20 )");
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        JTextField chooseSize=new JTextField(values.choosesize);
        chooseSize.setMaximumSize(new Dimension(100, 30));
        chooseSize.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel label2= new JLabel("Enter target value()");
        label2.setAlignmentX(Component.CENTER_ALIGNMENT);
        JTextField chooseTarget= new JTextField(Integer.toString(values.randomnumber));
        chooseTarget.setMaximumSize(new Dimension(100,30));

        JLabel label3 = new JLabel("Enter number of moves");
        label3.setAlignmentX(Component.CENTER_ALIGNMENT);
        JTextField chooseMoves = new JTextField(Integer.toString(values.numberofmoves));
        chooseMoves.setMaximumSize(new Dimension(100,30));

        JButton buttoncreating = new JButton("Generate");
        buttoncreating.setAlignmentX(Component.CENTER_ALIGNMENT);

        buttoncreating.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int value = Integer.parseInt(chooseSize.getText());
                int target=Integer.parseInt(chooseTarget.getText());
                int numberofmoves=Integer.parseInt(chooseMoves.getText());

                Container startOwnGamePanel = buttoncreating.getParent();
                Container frame = startOwnGamePanel.getParent();

                if(value>=10 && value <=20 && target>0 && numberofmoves>0 ) {
                    values.choosesize = value;
                    values.buttons = new JButton[values.choosesize][values.choosesize];
                    values.randomnumber = target;
                    values.numberofmoves = numberofmoves;
                    values.target.setText("Target Value:" + values.randomnumber);
                    values.movesleft.setText("Number of Moves: " + values.numberofmoves);
                    frame.remove(startOwnGamePanel);
                    frame.setMaximumSize(new Dimension(1080, 100));
                    GamePanel gamePanel = new GamePanel(values);
                    frame.add(gamePanel, BorderLayout.CENTER);
                    frame.revalidate();
                    frame.repaint();
                }else if(value<10||value>20){
                    JOptionPane.showMessageDialog(null,"Please choose size between 10-20!","Invalid Size",JOptionPane.ERROR_MESSAGE);
                }
                else if(target<=0){
                    JOptionPane.showMessageDialog(null,"Please choose a positive Target!","Invalid Target",JOptionPane.ERROR_MESSAGE);
                } else if (numberofmoves<=0) {
                    JOptionPane.showMessageDialog(null,"Please choose positive number of moves","Invalid Number of Moves",JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        add(Box.createVerticalGlue());
        add(label);
        add(chooseSize);
        add(label2);
        add(chooseTarget);
        add(label3);
        add(chooseMoves);
        add(buttoncreating);
        add(Box.createVerticalGlue());
    }
}
