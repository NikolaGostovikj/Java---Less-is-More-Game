/*

public class Hint {
       For a given node, i need to raise the sum, and check if sum>=target,
       if it is return the sum, return 1;
       i++ with every call of steps
       ifnumber of steps-i==0 || sum->target)
       using recursion
}
 */
