import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Random;

public class CheckingGame extends JPanel {

    Values values;
    JButton button;
    public CheckingGame(Values values, JButton button){
        this.values = values;
        this.button=button;

        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        checking();

    }

    public void checking(){
        add(Box.createVerticalGlue());
        if (values.currentsum>=values.randomnumber){
            JOptionPane.showMessageDialog(null,"CONGRATULATIONS! YOU WON! \n Remaining number of moves "+values.numberofmoves+"\n"+"You" +
                    "'ve reached the score of "+values.currentsum+"\n"+"You are above the target " +(values.currentsum-values.randomnumber),"Winner winner Chicken Dinner",JOptionPane.INFORMATION_MESSAGE);
        }else{
            JOptionPane.showMessageDialog(null,"YOU'VE LOST!YOU ARE NOT ALLOWED TO PLAY AGAIN! GO STUDY GUI!\n"+"Deviation:"+ (values.randomnumber-values.currentsum),"LOSER",JOptionPane.WARNING_MESSAGE);
        }




        Font font = new Font("Arial",Font.PLAIN,35);
        JButton buttonnewgame=  new JButton("New Game");
        JButton exit = new JButton("Exit");
        exit.setAlignmentX(Component.CENTER_ALIGNMENT);
        exit.setFont(font);
        buttonnewgame.setFont(font);
        exit.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonnewgame.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(buttonnewgame,BorderLayout.CENTER);
        add(Box.createVerticalStrut(20));
        add(exit,BorderLayout.CENTER);
        add(Box.createVerticalStrut(20));
        add(Box.createVerticalGlue());


        buttonnewgame.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Container checkingGame = buttonnewgame.getParent();
                Container frame = checkingGame.getParent();
                frame.remove(checkingGame);
                Values newValues = new Values();
                MainFrame mainframe = new MainFrame(newValues);
                frame.add(mainframe, BorderLayout.CENTER);

                frame.revalidate();
                frame.repaint();

            }
        });

        exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
    }
}
