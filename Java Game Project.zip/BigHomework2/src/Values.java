import javax.swing.*;
import java.util.ArrayList;
import java.util.*;
public class Values {

    int current=0;
    int previous=0;
    ArrayList<int []> availableMoves = new ArrayList<>(); //creating array list that will contain integer array
    // of available moves
    JLabel currentSumlabel= new JLabel("Current sum: "+0);
    Random randommoves = new Random();
    int numberofmoves= randommoves.nextInt(20-5+1)+5;
    int defaultMoves = numberofmoves;
    int currentsum=0;
    JLabel movesleft = new JLabel("Number of Moves: "+Integer.toString(numberofmoves));

    ArrayList<int []> inactiveButtons=new ArrayList<>();

    //making an array list that has an array of inactive buttons
    int choosesize = 10;
    Random randomtarget = new Random();
    int randomnumber = randomtarget.nextInt(100-1+1)+1;

    String gamemode = "Random";
    JLabel label = new JLabel("Gamemode "+gamemode);
    JLabel target = new JLabel(("Target Value:" +Integer.toString(randomnumber)));

    JButton buttons[][]=new JButton[choosesize][choosesize]; //2D array of buttons
    String buttonTexts[] = new String[choosesize]; //array that contains button text incase has been loaded or restarted

}
