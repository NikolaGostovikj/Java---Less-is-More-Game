import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;


public class MainFrame extends JPanel  {
   public MainFrame(Values values) {
       setLayout(new BoxLayout(this,BoxLayout.Y_AXIS));

       JOptionPane.showMessageDialog(null,"Welcome to More is Less,Less is More! Enjoy my game and Good Luck and Have Fun!","Welcoming",JOptionPane.INFORMATION_MESSAGE);

       JButton startGame = new JButton("Start Game");
       startGame.setAlignmentX(Component.CENTER_ALIGNMENT);
       JButton startRandomGame = new JButton("Start Random Game");
       startRandomGame.setAlignmentX(Component.CENTER_ALIGNMENT);
       JButton startOwnGame = new JButton("Start Own Game");
       startOwnGame.setAlignmentX(Component.CENTER_ALIGNMENT);
       JButton exit = new JButton("Exit");
       exit.setAlignmentX(Component.CENTER_ALIGNMENT);

       startGame.addActionListener(new ActionListener() {
           @Override
           public void actionPerformed(ActionEvent e) {
               Container mainFrame = startGame.getParent();
               Container frame = mainFrame.getParent();

               frame.remove(mainFrame);

               StartGamePanel startGamePanel = new StartGamePanel(values);
               frame.add(startGamePanel);

               frame.revalidate();
               frame.repaint();
           }
       });

       startRandomGame.addActionListener(new ActionListener() {
           @Override
           public void actionPerformed(ActionEvent e) {
               Container mainFrame = startGame.getParent();
               Container frame = mainFrame.getParent();

               frame.remove(mainFrame);

               GamePanel gamePanel = new GamePanel(values);
               frame.add(gamePanel);

               frame.revalidate();
               frame.repaint();
           }
       });

       startOwnGame.addActionListener(new ActionListener() {
           @Override
           public void actionPerformed(ActionEvent e) {
               Container mainFrame = startGame.getParent();
               Container frame = mainFrame.getParent();

               frame.remove(mainFrame);

               StartOwnGamePanel startOwnGamePanel = new StartOwnGamePanel(values);
               frame.add(startOwnGamePanel);

               frame.revalidate();
               frame.repaint();
           }
       });

       exit.addActionListener(new ActionListener() {
           @Override
           public void actionPerformed(ActionEvent e) {
               System.exit(0);
           }
       });

       add(Box.createVerticalGlue());
       add(startGame);
       add(Box.createVerticalStrut(20));
       add(startRandomGame);
       add(Box.createVerticalStrut(20));
       add(startOwnGame);
       add(Box.createVerticalStrut(20));
       add(exit);
       add(Box.createVerticalStrut(20));
       add(Box.createVerticalGlue());
    }
}