import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class Actions implements ActionListener {
    private JButton buttons[][];
    private Values values;
    private int buttonxy[];



    // Defining variables that are passed as parameters of the Action class.
    public Actions(JButton buttons[][], Values values, int buttonxy[]){
        this.buttons=buttons;
        this.values = values;
        this.buttonxy=buttonxy;

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // Defining boolean value that will be used in for to tell if this button is contained inside an ArrayList of possible buttons.
        boolean exist = false;
        for (int i = 0; i < values.availableMoves.size(); i++) {
            // Defining currentxy, from availableMoves ArrayList.
            // This variable is array that contains two numbers (x and y position of the button on the game field).
            int currentxy[] = values.availableMoves.get(i);
            // Using if statement to check if current button already exists in availableButtons.
            // If so, value of variable exist will be set to true.
            if (currentxy[0] == buttonxy[0] && currentxy[1] == buttonxy[1]) {
                exist = true;
            }
        }
        // Using the same way to check if this button has already been clicked.
        boolean isalreadyclicked=false;
        for (int i = 0; i < values.inactiveButtons.size() ; i++) {
            int currentxy[] = values.inactiveButtons.get(i);
            if (currentxy[0] == buttonxy[0] && currentxy[1] == buttonxy[1]) {
                isalreadyclicked = true;
                JOptionPane.showMessageDialog(null,"You've already clicked this button","Info",JOptionPane.ERROR_MESSAGE);
            }

        }


        // Checking if all conditions are met, so the game can be started.
        if((exist == true || values.current==0) && isalreadyclicked == false ) {
            values.availableMoves=new ArrayList<>();
            JButton button = (JButton) e.getSource();
            values.inactiveButtons.add(buttonxy);
            int value = Integer.parseInt(button.getText());
            values.currentsum+=value;
            values.numberofmoves-=1;
            values.currentSumlabel.setText("Current sum: "+ values.currentsum);
            values.movesleft.setText("Number of Moves:"+ values.numberofmoves);
            ArrayList<int[]> array = new ArrayList<>();

            // If current has value, that means that it isn't first move.
            // So, value can be added to previous variable.
            if (values.current != 0) {
                values.previous = values.current;
            }


            values.current = value;
            // Checking if any of conditions that can end the game are met.
            if(values.currentsum>= values.randomnumber || values.numberofmoves==0){
                Container gamepanel = button.getParent().getParent();
                Container frame = gamepanel.getParent();
                frame.remove(gamepanel);
                CheckingGame checkingGame = new CheckingGame(values, button);
                frame.add(checkingGame, BorderLayout.CENTER);
                frame.revalidate();
                frame.repaint();
            }


            // If statement will be active if this move is the first one in the game.
            if (values.previous == 0) {
                // Going through all rows, in the game field, starting from 1 (not from 0).
                for (int i = 1; i <= values.choosesize; i++) {
                    // If row number is divisible by button value, script will be continued.
                    if (i % value == 0) {
                        // Every element of row will be added to ArrayList array, that contains all of new available buttons.
                        for (int j = 1; j <= values.choosesize; j++) {
                            array.add(new int[]{i - 1, j - 1});

                        }
                    }
                }

                // Going through every element of ArrayList array and setting color to button on each coordinate of array element.
                for (int i = 0; i < array.size(); i++) {
                    int xy[] = array.get(i);
                    JButton newbutton = buttons[xy[0]][xy[1]];
                    Color color2= new Color(0x40C25A);
                    newbutton.setBackground(color2);
                    values.availableMoves.add(xy);
                }

                //Going through every element of ArrayList and setting color red to inactive button
                for (int i = 0; i < values.inactiveButtons.size(); i++) {
                    int xy[] = values.inactiveButtons.get(i);
                    JButton inactivebutton = buttons[xy[0]][xy[1]];
                    Color color = new Color(0xFC0A47);
                    inactivebutton.setBackground(color);
                }

            } else {
                //else because it is not the first move
                //defining 2 array lists with arrays inside
                ArrayList<int[]> previousArray = new ArrayList<>();
                ArrayList<int[]> currentArray = new ArrayList<>();
                //checking if column is divisible by the the previous button value
                for (int i = 1; i <= values.choosesize; i++) {
                    if (i % values.previous == 0) {
                        for (int j = 1; j <= values.choosesize; j++) {
                            previousArray.add(new int[]{j - 1, i - 1});
                            //adding to array list Previous array

                        }
                    }
                }

                //if row is divisible by the button value
                for (int i = 1; i <= values.choosesize; i++) {
                    if (i % values.current == 0) {
                        for (int j = 1; j <= values.choosesize; j++) {
                            currentArray.add(new int[]{i - 1, j - 1});

                        }
                    }
                }


                //Going through the currentArray arraylist and setting the button to cyan (inactive)
                for (int i = 0; i < currentArray.size(); i++) {
                    int xy[] = currentArray.get(i);
                    JButton newbutton = buttons[xy[0]][xy[1]];
                    newbutton.setBackground(Color.cyan);
                }

                //doing the arraylist with arrays called intersections which looks
                // for all the intersections between previous and current array
                ArrayList<int[]> intersections = new ArrayList<>();
                for (int i = 0; i < previousArray.size(); i++) {
                    boolean status = false;
                    int previousxy[] = previousArray.get(i);
                    for (int j = 0; j < currentArray.size(); j++) {
                        //going through every column in previous and row in current
                        int currentxy[] = currentArray.get(j);
                        //defining current element of arraylist currentArray as currenyxy.
                        // if element exists both in previousArray and currentArray that means that element is an intersection.
                        if (previousxy[0] == currentxy[0] && previousxy[1] == currentxy[1]) {
                            status = true;
                        }
                    }
                    if (status == true) {
                        intersections.add(previousxy);
                    }
                }

                // Starting to set colors for all buttons on the field from here.

                // First, all buttons will have color cyan.
                for (int i = 0; i < buttons.length; i++) {
                    for (int j = 0; j < buttons.length; j++) {
                        buttons[i][j].setBackground(Color.cyan);
                    }
                }

                // Every intersection will have green color.
                for (int i = 0; i < intersections.size(); i++) {
                    int xy[] = intersections.get(i);
                    JButton intersectbutton = buttons[xy[0]][xy[1]];
                    Color color3=new Color(0x40C25A);
                    intersectbutton.setBackground(color3);
                    values.availableMoves.add(xy);
                }

                // Every inactive button, button that cannot be clicked anymore will be painted to red.
                for (int i = 0; i < values.inactiveButtons.size(); i++) {
                    int xy[] = values.inactiveButtons.get(i);
                    JButton inactivebutton=buttons[xy[0]][xy[1]];
                    Color color=new Color(0xFC0A47);
                    inactivebutton.setBackground(color);
                }
            }

            // Checking if there is any possible continuation, after this move.

            boolean availableButtonsExist = false;

            for(int i = 0; i < buttons.length; i++) {
                for(int j = 0; j < buttons[i].length; j++) {
                    JButton currentbutton = buttons[i][j];
                    // Getting background of every button.
                    Color background = currentbutton.getBackground();

                    // Defining RGB as a separate variables, so they can be compared.
                    int red = background.getRed();
                    int green = background.getGreen();
                    int blue = background.getBlue();

                    // Comparing red, green and blue to RGB of button that is selectable.
                    if(red == 64 && green == 194 && blue == 90) {
                        // If such button exists, that means that possible continuations exist.
                        availableButtonsExist = true;
                    }
                }
            }

            // If there aren't any possible continuations the game will be finished.
            if(availableButtonsExist == false){
                Container gamepanel = button.getParent().getParent();
                Container frame = gamepanel.getParent();
                frame.remove(gamepanel);
                CheckingGame checkingGame = new CheckingGame(values, button);
                frame.add(checkingGame, BorderLayout.CENTER);
                JOptionPane.showMessageDialog(null,"You've run out of Available moves!","You Lost!",JOptionPane.WARNING_MESSAGE);
                frame.revalidate();
                frame.repaint();
            }

        }



    }
}
