import javax.swing.JFrame;
import java.awt.*;

public class Frame extends JFrame {
    Values values = new Values();


    public Frame() {

        setTitle("More is Less, Less is More!");
        setLayout(new BorderLayout());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setVisible(true);


        MainFrame mainframe = new MainFrame(values);//Calling the MainFrame class with parameter values
        add(mainframe,BorderLayout.CENTER);
        revalidate();
        repaint();
    }



    public static void main(String[] args) {
        new Frame();
    }


}
