import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

public class TargetValue extends JPanel {
    private Values values;
    public TargetValue(Values values){
        this.values = values;
        createTargetValue();//calling the method inside the constructor with parameter Values values
    }

       public void createTargetValue(){
           JButton savegame = new JButton("Save Game");
           JButton loadgame = new JButton("Load Game");
           JButton returnbutton = new JButton("Return");
           JButton restartbutton = new JButton("Restart");

           //Giving the return button an action
           returnbutton.addActionListener(new ActionListener() {
               @Override
               public void actionPerformed(ActionEvent e) {
                   Container targetValue = restartbutton.getParent(); //defining targetValue by getting the parent element of the button pressed
                   Container gamePanel = targetValue.getParent();
                   Container frame = gamePanel.getParent();

                   frame.remove(gamePanel); //removing the gamePanel because it is parent element all of the above will be removed

                   MainFrame mainFrame = new MainFrame(values);//MainFrame class with parameter values
                   frame.add(mainFrame);

                   frame.repaint();
                   frame.revalidate();
               }
           });

           savegame.addActionListener(new ActionListener() {
               @Override
               public void actionPerformed(ActionEvent e) {
                   //Used google and stackoverflow to search how to do the save button
                   //creating date and formating in Date,Month and Year format
                   //giving the gamename string the date-month-year format plus a random digit between 1-1000
                   Date date = new Date();
                   SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy HH-mm");
                   String gamename = simpleDateFormat.format(date);



                   try {
                       File savedfile = new File("Saves\\" + gamename + ".txt");//defining file that stands for txt file that will be written in
                       String infoValues="";
                       //random number is the target and choose size is the dimension, default moves is the number of moves
                       infoValues+=values.randomnumber+" "+values.choosesize+" "+values.defaultMoves+" ";
                       for (int i = 0; i < values.buttons.length ; i++) {
                           for (int j = 0; j < values.buttons[i].length; j++) { //searching for the current row on i index
                               String textbutton=values.buttons[i][j].getText();
                               infoValues+=textbutton;
                               infoValues+="-"; //saving the values of buttons with '-' character
                           }
                       }
                       FileWriter fileWriter = new FileWriter(savedfile);
                       BufferedWriter writer = new BufferedWriter(fileWriter);
                       writer.write(infoValues);
                       writer.close();

                   } catch (IOException ex) {    //surround with try catch, catches exceptions when io exception occurs
                       throw new RuntimeException(ex);
                   }

                   JOptionPane.showMessageDialog(null,"Your Game has been Saved!","GameSaver.version.1.3",JOptionPane.INFORMATION_MESSAGE);
                   Container gamepanel = savegame.getParent().getParent(); //Getting the parent element of save game(Target Value) then the parent of Target Value(game panel)
                   Container frame = gamepanel.getParent();
                   GamePanel newGamePanel=new GamePanel(values); //calling GamePanel class with parameter values
                   frame.remove(gamepanel); //removing old adding the new
                   frame.add(newGamePanel);
                   frame.repaint();
                   frame.revalidate();
               }
           });

           loadgame.addActionListener(new ActionListener() {
               @Override
               public void actionPerformed(ActionEvent e) {
                   String loadedgame = "";

                   JFileChooser chooser = new JFileChooser();
                   File file = new File("Saves");

                   chooser.setCurrentDirectory(file);
                   int result = chooser.showOpenDialog(null);

                   Values newValues = new Values();

                   if(result == JFileChooser.APPROVE_OPTION) {
                       File selectedFile = chooser.getSelectedFile();

                       try {
                           FileReader fileReader = new FileReader(selectedFile);
                           BufferedReader reader = new BufferedReader(fileReader);
                        //reading the line and infromation in txt file
                           loadedgame = reader.readLine();

                           reader.close();
                       } catch (IOException ex) {
                           throw new RuntimeException(ex);
                       }

                       String loadedinfo[] = loadedgame.split(" ");

                       //0 1 and 2 because of the order they appear
                       for(int i = 0; i < loadedinfo.length; i++) {
                           if(i == 0) {
                               int integer = Integer.parseInt(loadedinfo[i]);
                               newValues.randomnumber = integer;
                               newValues.target.setText("Target:"+Integer.toString(newValues.randomnumber));
                           }

                           else if(i == 1) {
                               int integer = Integer.parseInt(loadedinfo[i]);
                               newValues.choosesize = integer;
                               newValues.buttons = new JButton[integer][integer];
                           }

                           else if(i == 2) {
                               int integer = Integer.parseInt(loadedinfo[i]);
                               newValues.numberofmoves = integer;
                               newValues.defaultMoves = integer;
                               newValues.movesleft.setText("Number of Moves:"+Integer.toString(newValues.numberofmoves));
                           }

                           else {
                               String texts[] = loadedinfo[i].split("-");
                               newValues.buttonTexts = new String[texts.length];

                               for(int j = 0; j < texts.length; j++) {
                                   newValues.buttonTexts[j] = texts[j];
                               }
                           }
                       }
                       Container gamepanel = loadgame.getParent().getParent(); //Getting the parent element of save game(Target Value) then the parent of Target Value(game panel)
                       Container frame = gamepanel.getParent();
                       GamePanel newGamePanel=new GamePanel(newValues);
                       frame.remove(gamepanel);
                       frame.add(newGamePanel);
                       frame.repaint();
                       frame.revalidate();
                   }
               }
           });

           restartbutton.addActionListener(new ActionListener() {
               @Override
               public void actionPerformed(ActionEvent e) {
                   Container targetValue = restartbutton.getParent();
                   Container gamePanel = targetValue.getParent();
                   Container frame = gamePanel.getParent();

                   frame.remove(gamePanel);

                   Values newValues = new Values();

                    //keeping the previous values
                   newValues.choosesize = values.choosesize;
                   newValues.numberofmoves=values.defaultMoves;
                   newValues.defaultMoves = values.defaultMoves;
                   newValues.randomnumber=values.randomnumber;
                   int index = 0;
                   //keeping the values of the buttons
                   newValues.buttons = new JButton[values.choosesize][values.choosesize];
                   newValues.buttonTexts = new String[values.choosesize * values.choosesize];


                   for(int i = 0; i < newValues.buttons.length; i++) {
                       for(int j = 0; j < newValues.buttons[i].length; j++) {
                           newValues.buttonTexts[index] = values.buttons[i][j].getText();
                           index++;
                       }
                   }

                   //parsing the integer into string so they appear on the label
                   newValues.movesleft.setText("Number of Moves:"+Integer.toString(newValues.numberofmoves));
                   newValues.target.setText("Target:"+Integer.toString(newValues.randomnumber));


                   GamePanel newGamePanel = new GamePanel(newValues);
                   frame.add(newGamePanel);
                   frame.repaint();
                   frame.revalidate();
               }
           });

           setLayout(new BoxLayout(this,BoxLayout.X_AXIS));
           add(values.target);
           add(Box.createHorizontalGlue());
           add(values.label);
           add(Box.createHorizontalGlue());
           add(values.movesleft);
           add(Box.createHorizontalGlue());
           add(values.currentSumlabel);
           add(Box.createHorizontalGlue());
           add(savegame);
           add(Box.createHorizontalGlue());
           add(loadgame);
           add(Box.createHorizontalGlue());
           add(returnbutton);
           add(Box.createHorizontalGlue()); //adding space between
           add(restartbutton);
    }





}
