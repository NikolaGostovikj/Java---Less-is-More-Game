import javax.swing.*;
import java.awt.*;

public class GamePanel extends JPanel {

    //Calling the classes TargetValue and ButtonPanel inside the constructor with parameter values
    public GamePanel(Values values) {
        ButtonPanel buttonPanel = new ButtonPanel(values);
        TargetValue targetValue = new TargetValue(values);

        setLayout(new BorderLayout());
        add(targetValue, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.CENTER);
    }
}
